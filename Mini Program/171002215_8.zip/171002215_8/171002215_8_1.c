/*
 * @Description: 
 * @Version: 2.0
 * @Author: Kevin Liu
 * @Date: 2019-10-23 16:00:50
 * @LastEditors: Kevin Liu
 * @LastEditTime: 2019-10-23 16:22:02
 */
#include"apue.h"
#include"my_err.h"

void f(void)
{
    printf("1\n");
}

void f1(void)
{
    printf("2\n");
}

void main(void)
{
    atexit(f);
    atexit(f1);
}
