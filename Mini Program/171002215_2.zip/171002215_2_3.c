#include<stdio.h>
#include<stdlib.h>

int main()
{
    int a = 5, b = 7, c;
    c = (float)a/b;
    printf("(float)a/b=c(int)=%d\n",c);
    c = a/(float)b;
    printf("a/(float)b=c(int)=%d\n",c);
    float d;
    d = (float)a/b;
    printf("(float)a/b=d(float)=%f\n",d);
    d = a/(float)b;
    printf("a/(float)b=d(float)=%f\n",d);
    return 0;
}