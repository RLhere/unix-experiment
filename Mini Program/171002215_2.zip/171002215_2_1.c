#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stddef.h>

struct X
{
    char a;
    short b;
    int c;
};

struct Y
{
    char a;
    int c;
    short b;
};



int main()
{
    printf("Struct X bytes:%ld\nStruct Y bytes:%ld\n",sizeof(struct X),sizeof(struct Y));
    printf("Struct X space:%ld\nStruct Y space:%ld\n",offsetof(struct X,c)+sizeof(int),offsetof(struct Y,b)+sizeof(short));
    return 0;
}