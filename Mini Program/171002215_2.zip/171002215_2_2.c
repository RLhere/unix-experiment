#include<stdio.h>
#include<stdlib.h>

int main()
{
    int *a[5];
    int (*b)[5];
    printf("a ~ array( 5, *int):%ldBytes\nb ~ *array( 5, int):%ldBytes\n",sizeof(a),sizeof(b));
    return 0;
}