#include<stdio.h>
#include<stdlib.h>

int main()
{
    int *i;
    char *c;
//    int *i;

    printf("int*:%ld\nchar*:%ld\n",sizeof(i),sizeof(c));
    printf("i adress:%p\nc adress:%p\n",&i,&c);
    printf("i:%d\nc:%c\n",*i,*c);

    return 0;
}